package com.seattlesolvers.solverslib.hardware;

public interface HardwareDevice {

    void disable();

    String getDeviceType();

}
