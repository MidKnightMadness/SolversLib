package com.seattlesolvers.solverslib.util;

public enum Direction {
    LEFT, RIGHT, UP, DOWN, FORWARD, BACKWARDS
}
