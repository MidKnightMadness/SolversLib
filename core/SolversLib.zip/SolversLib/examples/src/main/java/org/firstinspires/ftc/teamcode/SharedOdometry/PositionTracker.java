package org.firstinspires.ftc.teamcode.SharedOdometry;

import com.seattlesolvers.solverslib.geometry.Pose2d;

public class PositionTracker {

    public static Pose2d robotPose;

}
